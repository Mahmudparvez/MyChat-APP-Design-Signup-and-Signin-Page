<!DOCTYPE html>
<html lang="en">
<head>
	<title>Create An Account</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content ="IE=edge">
	<meta name ="viewport" content ="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="../css/signup.css">


   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</head>
<body>


	<div class="signup-form">
			<form action="" method="post">

			<div class="form-header">
				<h2>Sign Up</h2>
				<p>Fill out this form and start chating with your friends.</p>
			</div>

			<div class="form-group">
				<label for="">Username</label>
				<input type="text" class="form-control" name="username" placeholder="Example:: mahmud32" autocomplete="off" required>
			</div>

			<div class="form-group">
				<label for="">Password</label>
				<input type="text" class="form-control" name="user_pass" placeholder="password" autocomplete="off" required>
			</div>

			<div class="form-group">
				<label for="">Email</label>
				<input type="text" class="form-control" name="email" placeholder="Example@gmail.com" autocomplete="off" required>
			</div>
			<div class="form-group">
				<label for="">Password</label>
				<input type="text" class="form-control" name="user_pass" placeholder="password" autocomplete="off" required>
			</div>

			<div class="form-group">
				<label for="">Country</label>
				<select class="form-control" name="user_country" required>
					<option disabled="">Select a Country</option>
					<option value="">USA</option>
					<option value="">BANGLADESH</option>
					<option value="">PAKISTAN</option>
					<option value="">INDIA</option>
					<option value="">SRILANGKA</option>
				</select>
			</div>

			<div class="form-group">
				<label for="">Gender</label>
				<select class="form-control" name="user_gender" required>
					<option disabled="">Select a Gender</option>
					<option value="">Male</option>
					<option value="">Female</option>
					<option value="">Other</option>
				</select>
			</div>

			<div class="form-group">
				<label for="" class="checkbox-inline"> <input type="checkbox" required>I Accept The <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>

			</div>



			<div class="form-group">
				<button  type="submit" class="btn btn-primary btn-block btn-lg" name="sign-up">Sign Up</button>
			</div>


           <!-- <?php //include("signup_user.php"); ?> -->

		</form>


		<div class="text-center-small" style="color:#fff;"> Already Have An Account?<a href="signin.php">Sign In</a></div>
	</div>
	
</body>
</html>